package jp.ne.sakura.vopaldragon.aiwolf.framework;

public interface Tactic extends GameEventListenr {

}