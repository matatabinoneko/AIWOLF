package com.gmail.takkyubu.tan;

import org.aiwolf.sample.lib.AbstractRoleAssignPlayer;

public class SimplePlayer extends AbstractRoleAssignPlayer {

	@Override
	public String getName() {
		return null;
	}

}
