from __future__ import print_function, division 
from .predictor_gat2016 import Predictor_15
from .predictor_sample5 import Predictor_5
from .tensor5460 import Tensor5460


