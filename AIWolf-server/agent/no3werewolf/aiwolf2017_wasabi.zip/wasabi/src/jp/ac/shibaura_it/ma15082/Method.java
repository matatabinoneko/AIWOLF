package jp.ac.shibaura_it.ma15082;

public enum Method {
	GETNAME,
	TALK,
	WHISPER,
	INITIALIZE,
	DAYSTART,
	FINISH,
	VOTE,
	ATTACK,
	DIVINE,
	GUARD,
	UPDATE,
	
	MAX,
	ALL;
}
