package jp.gmail.kogecha05.utils;

public class Const {
	final public static boolean DEBUG = false;

	final public static double INF = 11451419190721810893.0;
	final public static double EPS = 10e-20;
}
