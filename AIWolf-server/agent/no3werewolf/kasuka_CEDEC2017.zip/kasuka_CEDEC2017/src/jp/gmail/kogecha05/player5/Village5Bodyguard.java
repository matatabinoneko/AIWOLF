package jp.gmail.kogecha05.player5;

import org.aiwolf.common.data.Agent;
import org.aiwolf.common.net.GameInfo;
import org.aiwolf.common.net.GameSetting;

public class Village5Bodyguard extends Village5Villager {
	public void initialize(GameInfo Village5, GameSetting gameSetting) {
		throw new UnsupportedOperationException();
	}

	public void update(GameInfo gameInfo) {
		throw new UnsupportedOperationException();
	}

	public void dayStart() {
		throw new UnsupportedOperationException();
	}

	public void finish() {
		throw new UnsupportedOperationException();
	}

	public String talk() {
		throw new UnsupportedOperationException();
	}

	public String whisper() {
		throw new UnsupportedOperationException();
	}

	public Agent vote() {
		throw new UnsupportedOperationException();
	}

	public Agent attack() {
		throw new UnsupportedOperationException();
	}

	public Agent divine() {
		throw new UnsupportedOperationException();
	}

	public Agent guard() {
		throw new UnsupportedOperationException();
	}
}