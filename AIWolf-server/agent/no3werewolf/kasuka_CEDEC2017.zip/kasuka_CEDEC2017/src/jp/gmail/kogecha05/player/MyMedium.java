package jp.gmail.kogecha05.player;

import jp.gmail.kogecha05.player15.Village15Medium;
import jp.gmail.kogecha05.player5.Village5Medium;

public class MyMedium extends MyBasePlayer {
	{
		player5 = new Village5Medium();
		player15 = new Village15Medium();
	}
}