package jp.halfmoon.inaba.aiwolf.lib;

public class AgentParameterItem {

	public static final String FAVOR_RATE = "FavorRate";

	public static final String VOTE_RATE_WTOW = "VoteRate_WtoW";


	public static final String DEVINE_RATE_WTOW_WHITE = "DevineRate_WtoW_White";
	public static final String DEVINE_RATE_WTOW_BLACK = "DevineRate_WtoW_Black";







}
