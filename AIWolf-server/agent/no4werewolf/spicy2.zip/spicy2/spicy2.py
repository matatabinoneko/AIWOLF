#!/usr/bin/env python
from __future__ import print_function, division

# this is main script

import aiwolfpy
import aiwolfpy.contentbuilder as cb
import numpy as np
import random
# sample
import aiwolfpy.cash

#
myname = 'spicy2'

class PythonPlayer(object):

    def __init__(self, agent_name):
        # myname
        self.myname = agent_name

        # predictor from sample
        # DataFrame -> P
        self.predicter_15 = aiwolfpy.cash.Predictor_15()
        self.predicter_5 = aiwolfpy.cash.Predictor_5()
        # 勝数、陣営勝数の定義
        self.win_rate = [0 for i in range(15)]
        self.were_win_rate = [0 for i in range(15)]
        self.vila_win_rate = [0 for i in range(15)]

    def getName(self):
        return self.myname

    def initialize(self, base_info, diff_data, game_setting):
        #print(diff_data)
        # base_info
        self.base_info = base_info
        # game_setting
        self.game_setting = game_setting
        self.playerNum = self.game_setting['playerNum']
        # initialize
        if self.game_setting['playerNum'] == 15:
            self.predicter_15.initialize(base_info, game_setting)
            #人間リスト
            self.Hlist = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15]
        elif self.game_setting['playerNum'] == 5:
            self.predicter_5.initialize(base_info, game_setting)
            #人間リスト
            self.Hlist = [1,2,3,4,5]
            #勝ち数計算用
            if len(self.win_rate) == 15:
                del self.win_rate[4:14]
                del self.vila_win_rate[4:14]
                del self.were_win_rate[4:14]
        # 自分のID
        self.id = self.base_info['agentIdx']
        # 狼リスト
        self.Wlist = []
        # 狂人リスト
        self.Plist = []
        self.pp_comingout = True
        self.wolfList = []


        ### EDIT FROM HERE ###
        self.divined_list = []
        self.comingout = ''
        self.myresult = ''
        self.not_reported = False
        self.vote_declare = 0

        self.talkcnt = None
        self.talkcntlist = [0]*15

        self.Slist = [] #占い師ＣＯリスト
        self.seeList = []
        self.Mlist = [] #霊媒師ＣＯリスト
        self.Whitelist = [] #白リスト

        self.Woco = True
        self.votelist = []
        self.glaylist = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15]



    def update(self, base_info, diff_data, request):
        # print(base_info)

        # self.today = diff_data['day'][0]
        # print(self.today)

        # 生存者リスト
        self.aliveList = [i for i, x in self.base_info['statusMap'].items() if x == 'ALIVE']
        # ランダム値の生成
        self.rand_rate = random.random()

        for i in range(diff_data.shape[0]):
            if "COMINGOUT" in diff_data['text'][i]:
                if "SEER" in diff_data['text'][i] and not diff_data['agent'][i] in self.Slist:
                    self.Slist.append(diff_data['agent'][i])
                elif "MEDIUM" in diff_data['text'][i] and not diff_data['agent'][i] in self.Mlist:
                    self.Mlist.append(diff_data['agent'][i])
                elif "VILLAGER" in diff_data['text'][i] and not diff_data['agent'][i] in self.Whitelist:
                    self.Whitelist.append(diff_data['agent'][i])
                elif "POSSESSED" in diff_data['text'][i] and not diff_data['agent'][i] in self.Plist:
                    self.Plist.append(diff_data['agent'][i])
                elif "WEREWOLF" in diff_data['text'][i] and not diff_data['agent'][i] in self.Wlist:
                    self.Wlist.append(diff_data['agent'][i])


        if len(self.Mlist) + len(self.Slist) >= 5:
            self.votelist =self.Mlist + self.Slist
        self.glaylist = list(set(self.glaylist) - set(self.Slist) -set(self.Mlist))


        #     if self.base_info['myRole'] == 'WEREWOLF'
        #
        # print("Vote")
        # print(self.votelist)
        # print("Mlist")
        # print(self.Mlist)
        # print(self.Slist)

        #人間リストの更新
        if len(self.Slist) > 0:
            self.Hlist = list(set(self.Hlist) - set(self.Slist))
        if len(self.Wlist) > 0:
            self.Hlist = list(set(self.Hlist) - set(self.Wlist))
        if len(self.Plist) > 0:
            self.Hlist = list(set(self.Hlist) - set(self.Plist))
        # 生きてる人狼リスト
        self.aliveWlist = list(set(self.aliveList)& set(self.Wlist))



        for i in range(diff_data.shape[0]):
            #print(diff_data['text'][i])
            if diff_data['type'][i] == 'talk':
                a = diff_data['agent'][i]
                self.talkcntlist[a-1] =  self.talkcntlist[a-1] + 1
                #print(min(self.talkcntlist))
                # self.talkcntlist[b] = 1
                # print(self.talkcntlist)



        if request == 'DAILY_INITIALIZE':
            for i in range(diff_data.shape[0]):
                # print(diff_data['type'][i])

                if diff_data['type'][i] == 'talk':
                    self.not_reported = True
                    self.myresult = diff_data['text'][i]
                # IDENTIFY
                if diff_data['type'][i] == 'identify':
                    self.not_reported = True
                    self.myresult = diff_data['text'][i]

                # DIVINE
                if diff_data['type'][i] == 'divine':
                    self.not_reported = True
                    self.myresult = diff_data['text'][i]

                # GUARD
                if diff_data['type'][i] == 'guard':
                    self.myresult = diff_data['text'][i]

            # POSSESSED
            if self.base_info['myRole'] == 'POSSESSED':
                self.not_reported = True

        # UPDATE
        if self.game_setting['playerNum'] == 15:
            if self.base_info["day"] == 0 and request == 'DAILY_INITIALIZE' and self.game_setting['talkOnFirstDay'] == False:
                # update pred
                self.predicter_15.update_features(diff_data)
                self.predicter_15.update_df()

            elif self.base_info["day"] == 0 and request == 'DAILY_FINISH' and self.game_setting['talkOnFirstDay'] == False:
                # no talk at day:0
                self.predicter_15.update_pred()

            else:
                # update pred
                self.predicter_15.update(diff_data)
        else:
            self.predicter_5.update(diff_data)

        # 1なら試合終了
        game_end = 0
        for i in range(diff_data.shape[0]):
            if diff_data['type'][i] == 'finish':
                game_end = 1
                break
        if game_end == 1:
            # 勝利陣営（0:村、1:狼）
            win_camp = 0
            wolf_camp = []
            if self.game_setting['playerNum'] == 15:
                for i in range(diff_data.shape[0]):
                    idnum = diff_data["agent"][i]
                    # 狼が生きてたら狼チームの勝利
                    if diff_data['type'][i] == 'finish' and diff_data['text'][i].split()[2] == 'WEREWOLF' or diff_data['text'][i].split()[2] == "POSSESSED":
                        wolf_camp.append(idnum)
                        if diff_data['text'][i].split()[2] == 'WEREWOLF' and self.base_info['statusMap'][str(idnum)] == 'ALIVE':
                            win_camp = 1
                for i in range(1,16):
                    if win_camp == 1 and (i in wolf_camp):
                        self.were_win_rate[i-1] += 1
                        self.win_rate[i-1] += 1
                    elif win_camp == 0 and (i not in wolf_camp):
                        self.vila_win_rate[i-1] += 1
                        self.win_rate[i-1] += 1
            else: # 5人人狼
                for i in range(diff_data.shape[0]):
                    idnum = diff_data["agent"][i]
                    # 狼が生きてたら狼チームの勝利
                    if diff_data['type'][i] == 'finish' and diff_data['text'][i].split()[2] == 'WEREWOLF' or diff_data['text'][i].split()[2] == "POSSESSED":
                        wolf_camp.append(idnum)
                        if diff_data['text'][i].split()[2] == 'WEREWOLF' and self.base_info['statusMap'][str(idnum)] == 'ALIVE':
                            win_camp = 1
                for i in range(1,6):
                    if win_camp == 1 and (i in wolf_camp):
                        self.were_win_rate[i-1] += 1
                        self.win_rate[i-1] += 1
                    elif win_camp == 0 and (i not in wolf_camp):
                        self.vila_win_rate[i-1] += 1
                        self.win_rate[i-1] += 1

        # 占い師用ブラックリスト
        if base_info['myRole'] == 'SEER':
            for i in range(diff_data.shape[0]):
                if diff_data['type'][i] == 'divine' and diff_data['text'][i].split()[2] == 'WEREWOLF':
                    black = diff_data['text'][i].split()[1]
                    blackid = int(black.replace('Agent[','').replace(']',''))
                    self.wolfList.append(blackid)


    def dayStart(self):
        self.vote_declare = 0
        self.talk_turn = 0
        return None

    def talk(self):
        # パワープレイ用カミングアウト
        if int(self.base_info['day']) > 1 and len(self.aliveList) == 3 and self.pp_comingout:
            if self.base_info['myRole'] == 'POSSESSED':
                self.comingout = 'POSSESSED'
                self.pp_comingout = False
                self.talk_turn += 1
                return cb.comingout(self.id, self.comingout)
            elif self.base_info['myRole'] == 'WEREWOLF':
                if len(self.Plist) > 0:
                    self.comingout = 'WEREWOLF'
                    self.pp_comingout = False
                    self.talk_turn += 1
                    return cb.comingout(self.id, self.comingout)
            elif len(self.Slist) == 2 and (len(self.Plist) != 0 or len(self.Wlist) != 0):
                self.comingout = 'WEREWOLF'
                self.pp_comingout = False
                self.talk_turn += 1
                return cb.comingout(self.id, self.comingout)


        if self.game_setting['playerNum'] == 15:

            self.talk_turn += 1

            # 1.comingout anyway
            if self.base_info['myRole'] == 'SEER' and self.comingout == '':
                self.comingout = 'SEER'
                return cb.comingout(self.base_info['agentIdx'], self.comingout)
            elif self.base_info['myRole'] == 'MEDIUM' and self.comingout == '':
                self.comingout = 'MEDIUM'
                return cb.comingout(self.base_info['agentIdx'], self.comingout)
            elif self.base_info['myRole'] == 'POSSESSED' and self.comingout == '':
                self.comingout = 'SEER'
                return cb.comingout(self.base_info['agentIdx'], self.comingout)
            elif self.base_info['myRole'] == 'WEREWOLF' and self.comingout == '' and self.Woco == True:
                self.Woco = False
                rnd = random.randint(0,100)
                if rnd < 20:
                    self.comingout = 'SEER'
                    return cb.comingout(self.base_info['agentIdx'], self.comingout)

            # 2.report
            if self.base_info['myRole'] == 'SEER' and self.not_reported:
                self.not_reported = False
                return self.myresult
            elif self.base_info['myRole'] == 'MEDIUM' and self.not_reported:
                self.not_reported = False
                return self.myresult
            elif self.base_info['myRole'] == 'POSSESSED' and self.not_reported:
                if self.rand_rate < 0.8:
                    self.not_reported = False
                    # FAKE DIVINE
                    # highest prob ww in alive agents
                    p = -1
                    idx = 1
                    p0_mat = self.predicter_15.ret_pred()
                    for i in range(1, 16):
                        p0 = p0_mat[i-1, 1]
                        if self.base_info['statusMap'][str(i)] == 'ALIVE' and p0 > p:
                            p = p0
                            idx = i
                    self.myresult = 'DIVINED Agent[' + "{0:02d}".format(idx) + '] ' + 'HUMAN'
                    return self.myresult
                else:
                    self.not_reported = False
                    # FAKE DIVINE
                    # highest prob ww in alive agents
                    p = -1
                    idx = 1
                    p0_mat = self.predicter_15.ret_pred()
                    for i in range(1, 16):
                        p0 = p0_mat[i-1, 1]
                        if self.base_info['statusMap'][str(i)] == 'ALIVE' and p0 > p:
                            p = p0
                            idx = i
                    self.myresult = 'DIVINED Agent[' + "{0:02d}".format(idx) + '] ' + 'WEREWOLF'
                    return self.myresult

            elif self.base_info['myRole'] == 'WEREWOLF' and self.not_reported and self.comingout == 'SEER':
                if self.rand_rate < 0.8:
                    self.not_reported = False
                    # FAKE DIVINE
                    # highest prob ww in alive agents
                    p = -1
                    idx = 1
                    p0_mat = self.predicter_15.ret_pred()
                    for i in range(1, 16):
                        p0 = p0_mat[i-1, 1]
                        if self.base_info['statusMap'][str(i)] == 'ALIVE' and p0 > p:
                            p = p0
                            idx = i
                    self.myresult = 'DIVINED Agent[' + "{0:02d}".format(idx) + '] ' + 'HUMAN'
                    return self.myresult
                else:
                    self.not_reported = False
                    # FAKE DIVINE
                    # highest prob ww in alive agents
                    p = -1
                    idx = 1
                    p0_mat = self.predicter_15.ret_pred()
                    for i in range(1, 16):
                        p0 = p0_mat[i-1, 1]
                        if self.base_info['statusMap'][str(i)] == 'ALIVE' and p0 > p:
                            p = p0
                            idx = i
                    self.myresult = 'DIVINED Agent[' + "{0:02d}".format(idx) + '] ' + 'WEREWOLF'
                    return self.myresult

            # 3.declare vote if not yet
            if self.vote_declare != self.vote():
                self.vote_declare = self.vote()
                return cb.vote(self.vote_declare)

            # 4. skip
            if self.talk_turn <= 10:
                return cb.skip()

            return cb.over()
        #５人
        else:
            self.talk_turn += 1

            # 1.comingout anyway
            if self.base_info['myRole'] == 'SEER' and self.comingout == '':
                self.comingout = 'SEER'
                return cb.comingout(self.base_info['agentIdx'], self.comingout)
            elif self.base_info['myRole'] == 'MEDIUM' and self.comingout == '':
                self.comingout = 'MEDIUM'
                return cb.comingout(self.base_info['agentIdx'], self.comingout)
            elif self.base_info['myRole'] == 'POSSESSED' and self.comingout == '':
                self.comingout = 'SEER'
                return cb.comingout(self.base_info['agentIdx'], self.comingout)
            # 20%で占い師CO
            elif self.base_info['myRole'] == 'WEREWOLF' and self.comingout == '' and self.rand_rate < 0.2:
                self.comingout = 'SEER'
                return cb.comingout(self.base_info['agentIdx'], self.comingout)

            # 2.report
            if self.base_info['myRole'] == 'SEER' and self.not_reported:
                self.not_reported = False
                return self.myresult
            elif self.base_info['myRole'] == 'MEDIUM' and self.not_reported:
                self.not_reported = False
                return self.myresult
            elif self.base_info['myRole'] == 'POSSESSED' and self.not_reported:
                self.not_reported = False
                # FAKE DIVINE
                # highest prob ww in alive agents
                p = -1
                idx = 1
                p0_mat = self.predicter_5.ret_pred_wx(2)
                for i in range(1, 6):
                    p0 = p0_mat[i-1, 1]
                    if self.base_info['statusMap'][str(i)] == 'ALIVE' and p0 > p:
                        p = p0
                        idx = i
                self.myresult = 'DIVINED Agent[' + "{0:02d}".format(idx) + '] ' + 'HUMAN'
                return self.myresult

            # 3.declare vote if not yet
            if self.vote_declare != self.vote():
                self.vote_declare = self.vote()
                return cb.vote(self.vote_declare)

            # 4. skip
            if self.talk_turn <= 10:
                return cb.skip()

            return cb.over()

    def whisper(self):
        return cb.skip()

    def vote(self):
        # パワープレイ
        if len(self.aliveList) == 3 and self.base_info['day'] > 1 and len(self.Wlist) > 0 and len(self.Plist) > 0:
            id_num = []
            if self.base_info['myRole'] == "WEREWOLF" or self.base_info['myRole'] == "POSSESSED":
                if len(self.Hlist) > 0:
                    id_num = self.Hlist
                elif len(self.aliveWlist) > 1:
                    if self.base_info['myRole'] == "WEREWOLF":
                        id_num = self.aliveWlist.remove(str(self.id))
                    else:
                        p = -1
                        idx = 1
                        if self.playerNum == 15:
                            p0_mat = self.predicter_15.ret_pred_wn()
                        else:
                            p0_mat = self.predicter_5.ret_pred_wx(2)
                        for i in range(1, (self.playerNum + 1)):
                            p0 = p0_mat[i-1, 1]
                            if self.base_info['statusMap'][str(i)] == 'ALIVE' and p0 > p:
                                p = p0
                                idx = i
                            return idx

            if self.base_info['myRole'] == "VILLAGER" or self.base_info['myRole'] == "SEER":
                if len(self.Wlist) > 0:
                    id_num = self.Wlist
                elif len(self.Hlist) == 2 and self.Hlist[0] in self.aliveList and self.Hlist[1] in self.aliveList :
                    if self.id in self.Hlist:
                        self.Hlist.remove(str(self.id))
                        idx = int(self.Hlist[0])
                    else:
                        if self.rand_rate < 0.5:
                            idx = int(self.Hlist[0])
                        else:
                            idx = int(self.Hlist[1])
                    if idx:
                        return idx
            if len(id_num) != 0 and not(len(id_num) == 1 and id_num[0] == self.id):
                idx = int(id_num[0])
                return idx

        if self.game_setting['playerNum'] == 15:
            p0_mat = self.predicter_15.ret_pred_wn()
            if self.base_info['myRole'] == "WEREWOLF":
                p = -1
                idx = 1
                for i in range(1, 16):
                    p0 = p0_mat[i-1, 1]
                    if str(i) in self.base_info['roleMap'].keys():
                        p0 *= 0.5
                    if self.base_info['statusMap'][str(i)] == 'ALIVE' and p0 > p:
                        p = p0
                        idx = i
            elif self.base_info['myRole'] == "POSSESSED":
                p = -1
                idx = 1
                for i in range(1, 16):
                    p0 = p0_mat[i-1, 1]
                    if self.base_info['statusMap'][str(i)] == 'ALIVE' and p0 > p:
                        p = p0
                        idx = i
            elif self.base_info['myRole'] == "SEER":
                # highest prob ww in alive agents provided watashi ningen
                p = -1
                idx = 1
                for i in range(1, 16):
                    p0 = p0_mat[i-1, 1]
                    if self.base_info['statusMap'][str(i)] == 'ALIVE' and p0 > p:
                        p = p0
                        idx = i


            else:
                if len(self.Slist) > 2 and self.base_info['day'] < 4:
                    idx = 1
                    for i in self.Slist:
                        if self.base_info['statusMap'][str(i)] == 'ALIVE':
                    #self.idx = i
                    # return self.idx
                            idx = i
                            break
                else:
                    idx = 1
                    p = -1
                    for i in range(1, 16):
                        p0 = p0_mat[i-1, 1]
                        if self.base_info['statusMap'][str(i)] == 'ALIVE' and p0 > p:
                            p = p0
                            idx = i
            return idx

        #5人
        else:
            if self.base_info['myRole'] == "WEREWOLF":
                p0_mat = self.predicter_5.ret_pred_wx(1)
                p = -1
                idx = 1
                for i in range(1, 6):
                    p0 = p0_mat[i-1, 3]
                    if self.base_info['statusMap'][str(i)] == 'ALIVE' and p0 > p:
                        p = p0
                        idx = i
            elif self.base_info['myRole'] == "POSSESSED":
                p0_mat = self.predicter_5.ret_pred_wx(2)
                p = -1
                idx = 1
                for i in range(1, 6):
                    p0 = p0_mat[i-1, 3]
                    if self.base_info['statusMap'][str(i)] == 'ALIVE' and p0 > p:
                        p = p0
                        idx = i
            elif self.base_info['myRole'] == "SEER" :
                idx = 1
                p0_mat = self.predicter_5.ret_pred_wx(3)
                p = -1
                for i in range(1, 6):
                    p0 = p0_mat[i-1, 1]
                    if self.base_info['statusMap'][str(i)] == 'ALIVE' and p0 > p:
                        p = p0
                        idx = i

                if len(self.wolfList) != 0:
                    for i in range(1, 6):
                        if self.base_info['statusMap'][str(i)] == 'ALIVE' and i in self.wolfList:
                            idx = i
                            break
                        break

            else:
                idx = 1
                ##占い師ＣＯが2人なら占い師以外に投票
                if len(self.Slist) == 2:
                    for i in range(1, 6):
                        if self.base_info['statusMap'][str(i)] == 'ALIVE' and not (i in self.Slist) and (i != self.id):
                            idx = i
                        else:
                            continue
                        break

                else:
                    p0_mat = self.predicter_5.ret_pred_wx(0)
                    p = -1
                    for i in range(1, 6):
                        p0 = p0_mat[i-1, 1]
                        if self.base_info['statusMap'][str(i)] == 'ALIVE' and p0 > p:
                            p = p0
                            idx = i
            return idx

    def attack(self):
        if self.game_setting['playerNum'] == 15:
            # highest prob hm in alive agents
            rnd = random.randint(0,100)
            if rnd < 50:
                p = -1
                idx = 1
                p0_mat = self.predicter_15.ret_pred()
                for i in range(1, 16):
                    p0 = p0_mat[i-1, 0]
                    if self.base_info['statusMap'][str(i)] == 'ALIVE' and p0 > p:
                        p = p0
                        idx = i
                return idx
            elif rnd >= 50:
                for i in range(1, 16):
                    if self.base_info['statusMap'][str(i)] == 'ALIVE':
                        idx = i
                return idx

        else:
            idx = self.id
            # 占いCOが1人ならそいつを、2人なら占い師以外の強い村人を襲撃
            if self.base_info['day'] == 1 and ((len(self.Slist) == 1 and int(self.Slist[0]) == self.id) or len(self.Slist) > 0) :
                if len(self.Slist) == 1 and int(self.Slist[0]) != self.id:
                    idx = int(self.Slist[0])
                elif len(self.Slist) > 1 :
                    vilaWinList = np.argsort(self.vila_win_rate)[::-1] + 1
                    strongVil = vilaWinList.tolist()
                    for i in self.Slist:
                        strongVil.remove(i)

                    if int(strongVil[0]) == self.id:
                        idx = int(strongVil[1])
                    else:
                        idx = int(strongVil[0])
            else:
                # lowest prob ps in alive agents
                p = 1
                idx = 1
                p0_mat = self.predicter_5.ret_pred_wx(1)
                for i in range(1, 6):
                    p0 = p0_mat[i-1, 2]
                    if self.base_info['statusMap'][str(i)] == 'ALIVE' and p0 < p and i != self.base_info['agentIdx']:
                        p = p0
                        idx = i
            return idx

    def divine(self):
        if self.game_setting['playerNum'] == 15:
            # highest prob ww in alive and not divined agents provided watashi ningen
            idx = 1

            for i in self.glaylist:
                if self.base_info['statusMap'][str(i)] == 'ALIVE' and i not in self.divined_list:
            # # p = -1
            # # idx = 1
            # # p0_mat = self.predicter_15.ret_pred_wn()
            # # for i in range(1, 16):
            # #     p0 = p0_mat[i-1, 1]
            # #     if self.base_info['statusMap'][str(i)] == 'ALIVE' and i not in self.divined_list and p0 > p:
            # #         p = p0
                    idx = i
            self.divined_list.append(idx)
            return idx
        else:
            # highest prob ww in alive and not divined agents provided watashi ningen
            p = -1
            idx = 1
            p0_mat = self.predicter_5.ret_pred_wx(3)
            for i in range(1, 6):
                p0 = p0_mat[i-1, 1]
                if self.base_info['statusMap'][str(i)] == 'ALIVE' and i not in self.divined_list and p0 > p:
                    p = p0
                    idx = i
            self.divined_list.append(idx)
            return idx

    def guard(self):
        if self.game_setting['playerNum'] == 15:
            # highest prob hm in alive agents
            p = -1
            idx = 1
            p0_mat = self.predicter_15.ret_pred()
            for i in range(1, 16):
                p0 = p0_mat[i-1, 0]
                if self.base_info['statusMap'][str(i)] == 'ALIVE' and p0 > p:
                    p = p0
                    idx = i
            return idx
        else:
            # no need
            return 1

    def finish(self):
        pass



agent = PythonPlayer(myname)

# run
if __name__ == '__main__':
    aiwolfpy.connect_parse(agent)
