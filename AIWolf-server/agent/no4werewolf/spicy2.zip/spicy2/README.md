必要環境
	* Python(3.6.5で動作確認しています)
	* 標準パッケージ, numpy, scipy, pandas, sciki-learn, random

* エージェントの接続
	* ./spicy2.py -h localhost -p 10000
