ファイルの説明：
  analysisフォルダ：解析用のログと、分析用のipynbファイル2点、そして分析に使うモジュールaiwolfpyが格納されている。
      解析用ログ：「20180302-033815-752」の000.log~099.log
      
      分析ファイル：1. aiwolf_possessed.ipynb
      　　　　　　　　　狂人が勝つための行動パターンをを分析した
                  2. aiwolf_drawing_graph.ipynb
                  　　5人人狼で、各投票ごとに誰がどこに投票したかを、グラフ理論で可視化した
                  ※上記のファイルを正常に動かすためには、以下のパッケージが必要。
                    ・jupyter
                    ・numpy
                    ・pandas
                    ・matplotlib
                    ・networkx
