package com.gmail.kanpyo2018.util;

public class AliveUpdate {
	
}
