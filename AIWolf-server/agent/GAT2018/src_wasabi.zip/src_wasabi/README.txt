﻿/***************************************

* TeamName	: wasabi
* Author 	: Mizukoshi Toshiki
* Date	 	: 2017/03/03
* e-mail 	: ma15082@shibaura-it.ac.jp

***************************************/

開発環境 : Eclipse Neon

java version : JavaSE-1.7

jarファイル:
aiwolf-client.jar (0.4.11)
aiwolf-common.jar (0.4.11)
aiwolf-server.jar (0.4.11)
jsonic-1.3.10.jar

プレイヤークラス名:
jp.ac.shibaur_it.ma15082.player.WasabiRoleAssignPlayer


