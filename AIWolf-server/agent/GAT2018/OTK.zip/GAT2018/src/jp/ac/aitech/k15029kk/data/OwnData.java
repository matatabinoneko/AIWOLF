package jp.ac.aitech.k15029kk.data;

public class OwnData {
	/*
	 * ビット演算
	 *
	 */
}
