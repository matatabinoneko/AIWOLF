/**
 * 役職を管理するクラスをもつパッケージ<br>
 * このパッケージ内のクラスを変更することで役職別の処理を実装する
 * @author k14096kk
 */
package com.gmail.k14.itolab.aiwolf.role;