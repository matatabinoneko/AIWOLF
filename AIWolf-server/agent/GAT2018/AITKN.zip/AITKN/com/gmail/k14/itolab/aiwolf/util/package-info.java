/**
 * 便利系のクラスをもつパッケージ
 * @author k14096kk
 */
package com.gmail.k14.itolab.aiwolf.util;