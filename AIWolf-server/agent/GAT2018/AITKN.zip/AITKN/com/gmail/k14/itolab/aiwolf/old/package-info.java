/**
 * 古いファイル(不使用なもの)
 * @author k14096kk
 */
package com.gmail.k14.itolab.aiwolf.old;