/**
 * エージェントの行動を管理するクラスをもつパッケージ
 * @author k14096kk
 */
package com.gmail.k14.itolab.aiwolf.action;