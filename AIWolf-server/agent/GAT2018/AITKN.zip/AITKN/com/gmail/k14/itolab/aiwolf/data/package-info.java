/**
 * ゲームで用いるデータの管理を行うクラスをもつパッケージ
 * @author k14096kk
 */
package com.gmail.k14.itolab.aiwolf.data;