/**
 * ゲームに参加する自作プレイヤーを管理するクラスをもつパッケージ
 * @author k14096kk
 */
package com.gmail.k14.itolab.aiwolf.player;