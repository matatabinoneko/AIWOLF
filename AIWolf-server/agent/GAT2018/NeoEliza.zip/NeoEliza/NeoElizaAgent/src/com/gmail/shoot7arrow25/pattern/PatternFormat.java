package com.gmail.shoot7arrow25.pattern;

import com.google.common.collect.ImmutableMap;
import org.aiwolf.common.data.Role;

import java.util.HashMap;

public class PatternFormat {
    HashMap<ImmutableMap<Integer, Role>, Double> patternScoreLists = new HashMap<>();
    HashMap<ImmutableMap<Integer, Role>, Double> myPatternScoreLists = new HashMap<>();
}
