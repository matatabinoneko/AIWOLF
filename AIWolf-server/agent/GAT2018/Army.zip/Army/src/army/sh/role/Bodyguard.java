package army.sh.role;

import org.aiwolf.common.data.Agent;
import org.aiwolf.common.net.GameInfo;

import army.sh.base.BaseRole;

public class Bodyguard extends BaseRole{

	@Override
	public Agent guard() {
		return me;
	}


	
	
}
