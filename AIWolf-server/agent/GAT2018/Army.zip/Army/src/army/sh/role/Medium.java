package army.sh.role;

import army.sh.base.BaseRole;

public class Medium extends BaseRole{

	
	
	
}
