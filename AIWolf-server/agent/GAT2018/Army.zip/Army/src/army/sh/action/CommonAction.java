package army.sh.action;

import java.util.ArrayDeque;
import java.util.Queue;

public class CommonAction {
	
	

}
