package com.gmail.aiwolf.uec.yk.strategyplayer;

import java.util.ArrayList;
import java.util.List;

import com.gmail.aiwolf.uec.yk.guess.AbstractGuessStrategy;
import com.gmail.aiwolf.uec.yk.guess.Guess;

/**
 * �e������p�N���X����󂯎��������
 */
public final class ReceivedGuess {

	/** �����̓��e */
	public Guess guess;

	/** �������s������p */
	public AbstractGuessStrategy strategy;

	/** �����̏d��(�W��^�����̏d��) */
	public double weight = 1.0;


	public ReceivedGuess(Guess guess, AbstractGuessStrategy strategy){
		this.guess = guess;
		this.strategy = strategy;
	}


	public ReceivedGuess(Guess guess, AbstractGuessStrategy strategy, double weight){
		this.guess = guess;
		this.strategy = strategy;
		this.weight = weight;
	}

	public static List<ReceivedGuess> newGuesses(ArrayList<Guess> guesses, AbstractGuessStrategy strategy){

		ArrayList<ReceivedGuess> rguesses = new ArrayList<ReceivedGuess>();

		for(Guess guess: guesses){
			ReceivedGuess rguess = new ReceivedGuess(guess, strategy);
			rguesses.add(rguess);
		}

		return rguesses;

	}

	public static List<ReceivedGuess> newGuesses(ArrayList<Guess> guesses, AbstractGuessStrategy strategy, double weight){

		ArrayList<ReceivedGuess> rguesses = new ArrayList<ReceivedGuess>();

		for(Guess guess: guesses){
			ReceivedGuess rguess = new ReceivedGuess(guess, strategy, weight);
			rguesses.add(rguess);
		}

		return rguesses;

	}

}
