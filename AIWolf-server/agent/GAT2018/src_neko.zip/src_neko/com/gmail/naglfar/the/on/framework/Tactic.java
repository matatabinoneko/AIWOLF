package com.gmail.naglfar.the.on.framework;

public interface Tactic extends GameEventListenr {

}