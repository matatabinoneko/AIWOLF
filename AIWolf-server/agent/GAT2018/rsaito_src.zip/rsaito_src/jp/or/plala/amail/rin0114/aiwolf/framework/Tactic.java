package jp.or.plala.amail.rin0114.aiwolf.framework;

public interface Tactic extends GameEventListenr {

}